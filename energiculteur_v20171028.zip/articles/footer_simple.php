<?php
	$folder='../';
	include($folder.'footer_simple.php');
?>