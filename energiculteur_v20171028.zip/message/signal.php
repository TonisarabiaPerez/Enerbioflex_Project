<html>
<body>

<form action="message2.php" method="post">
Enter Command: <input type="text" name="name"><br>
<input type="submit">
</form>

</body>
</html> 
