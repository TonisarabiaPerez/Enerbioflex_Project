<?php session_start();
include('header.php');
include('menuExemple.php');
?>
<div id="principal">Votre texte ici</div>
<?php
include('footer.php');
?>