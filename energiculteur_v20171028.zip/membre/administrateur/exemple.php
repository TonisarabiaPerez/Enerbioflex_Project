<?php session_start();
include('header.php');
include('menuExemple.php');

include('footer.php');
?>