<?php
	$folder='../';
	include ('function.php');
	include($folder.'header_simple.php');
?>