<?php 
$PARAM_hote        = 'localhost'; 
$PARAM_nom_bd      = 'thintank'; 
$PARAM_utilisateur = 'root'; 
$PARAM_mot_passe   = ''; 
$PARAM_nom_site    = 'Enerbioflex Think Tank'; 
$PARAM_mail_site   = 'enerbioflex@gmail.com'; 
$PARAM_pass_site    = ''; 
 
?>
