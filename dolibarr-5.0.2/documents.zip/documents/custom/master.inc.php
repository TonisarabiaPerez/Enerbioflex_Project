<?php
// Wrapper to include master into htdocs
include_once '/kunden/homepages/15/d638151069/htdocs/dolibarr-3.9.3/dolibarr-3.9.3/htdocs/master.inc.php';
