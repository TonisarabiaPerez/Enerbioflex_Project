<?php 
$PARAM_hote        = 'localhost'; 
$PARAM_nom_bd      = 'energiculteur'; 
$PARAM_utilisateur = 'energiculteur'; 
$PARAM_mot_passe   = 'Enerbioflex2016'; 
$PARAM_nom_site    = 'Enerbioflex Think Tank'; 
$PARAM_mail_site   = 'contact@enerbioflex.fr'; 
$PARAM_pass_site    = ''; 
$PARAM_url_site    = 'www.energiculteur.fr'; 
?>