<?php
	$folder='../';
	include('../header.php');
	include('../function.php');
?>