<?php
include("header.php")
?>

<h1> Informations pratiques </h1>
<hr width="100%" color="2a95be"/>
<p>
<img id="groslogo" src="Images/logo2.png" alt="Logo" />
<h3>
	Ce site se veut être un Think Tank de l'agriculture de demain. <br/>
	L'agriculture 3.0 commence aujourd'hui, rejoignez nous ! <br/>
</h3>
La troisième révolution industrielle agricole est en marche et passe par l'évolution de l'agriculture en une agriculture productrice de matière <br/>MAIS AUSSI productrice d'énergie.<br/>
Le métier se complexifie et demande de plus en plus de savoir faire.<br/>
Venez contribuer à l'évolution du métier !<br/>
</p>
<br/><a class="lien" href="http://www.enerbioflex.fr/" target="_blank">-> Site principal d'Enerbioflex </a>
<br/><a class="lien" href="contactez.php">-> Contactez-Nous</a>
<br/><a class="lien" href="plandusite.php">-> Plan du Site  </a>
<br/><br/>
<p>Ce site est optimisé pour le navigateur Google Chrome. Certaines fonctionnalités risquent de fonctionner différements sur les autres navigateurs. <br/>
Pour une meilleure navigation sur smartphone, une application Android sera bientôt disponible. <br/>
</p>
<?php
include("footer.php")
?>
