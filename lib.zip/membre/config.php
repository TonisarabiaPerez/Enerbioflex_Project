<?php 
$PARAM_hote        = 'localhost'; 
$PARAM_nom_bd      = 'enerbioflex'; 
$PARAM_utilisateur = 'root'; 
$PARAM_mot_passe   = ''; 
$PARAM_nom_site    = 'Enerbioflex Think Tank'; 
$PARAM_mail_site   = 'ddfdfdf@ddd.fr'; 
$PARAM_pass_site    = '123'; 
$PARAM_url_site    = 'www.monsite.fr/membre'; 
?>