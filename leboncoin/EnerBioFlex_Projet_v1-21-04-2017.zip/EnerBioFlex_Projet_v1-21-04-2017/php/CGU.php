<?php 
	require 'functions.inc.php';
	
	head_html( 'Inscription', "../img/logo.png", array( "../css/base.css", 
	"../css/contenu-box.css" , 
	"../media/FR_regnew_js/cmap/style.css",
	"../vendor/bootstrap-3.3.7-dist/css/bootstrap.min.css",
	"../vendor/bootstrap-3.3.7-dist/css/bootstrap-theme.min.css"
	) ,''
	);
?>

	<body>
		
		<?php
			session_start();
		
			//Barre
			bar('CGU');	
			
		?>
		
		<h1> Conditions Generales d'Utilisation </h1>
		
		<div id="box">
			<p class="text-center">
			ezef
			</p>
		</div>