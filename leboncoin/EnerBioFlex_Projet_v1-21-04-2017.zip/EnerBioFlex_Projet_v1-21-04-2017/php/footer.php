<?php

	require_once('functions.inc.php');
	// Entete
		head_html( ' ', "../img/logo.png", array( "../footer.css",
		),'');
?>	<footer id="footer">
        <div class="container">
            <div class="row">
                <div class="col-sm-6">
                    © 2016 Enerbioflex
                </div>
                <div class="col-sm-6">
                    <ul class="social-icons">
			<li>Suivez nous sur les réseaux sociaux </li><li>
                        </li><li><a href="http://www.facebook.com/enerbioflex/info/?tab=page_info"><i class="fa fa-facebook"></i></a></li>
                        <li><a href="https://twitter.com/enerbioflex"><i class="fa fa-twitter"></i></a></li>
                        <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                        <li><a href="#"><i class="fa fa-youtube"></i></a></li>
                        <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                    </ul>
                </div>
                <div class="col-sm-6">
                    Contactez nous par télphone : 06 87 38 54 53 / 06 80 45 39 59
                </div>
            </div>
        </div>
    <div></div></footer>