<?php


include('webservices.php');

envoieMail('remisafon@gmail.com', '[MAIL - ENERBIOFLEX]  TEST', 'JUSTE UN TEST', '<p>JUSTE UN TEST<\p>');

?>