<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="EnerBioFlex : Bureau d'études indépendant permettant aux agriculteurs de faire des économies d'énergie à la ferme et de produire de l'énergie renouvelable sur leur exploitation. ">
    <meta name="author" content="">
    <title>Enerbioflex - Economies d'énergie à la ferme</title>
	<!-- core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.1/css/font-awesome.min.css">
    <link href="css/animate.min.css" rel="stylesheet">
    <link href="css/owl.carousel.css" rel="stylesheet">
    <link href="css/owl.transitions.css" rel="stylesheet">
    <link href="css/prettyPhoto.css" rel="stylesheet">
    <link href="css/main.css" rel="stylesheet">
    <link href="css/responsive.css" rel="stylesheet">
    <link href="css/custom.css" rel="stylesheet">
    <!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>
    <script src="js/respond.min.js"></script>
    <![endif]-->       
    <link rel="shortcut icon" href="images/ico/favicon.ico">
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="images/ico/apple-touch-icon-144-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="images/ico/apple-touch-icon-114-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="images/ico/apple-touch-icon-72-precomposed.png">
    <link rel="apple-touch-icon-precomposed" href="images/ico/apple-touch-icon-57-precomposed.png">

<script type="text/javascript">
    window.smartlook||(function(d) {
    var o=smartlook=function(){ o.api.push(arguments)},h=d.getElementsByTagName('head')[0];
    var c=d.createElement('script');o.api=new Array();c.async=true;c.type='text/javascript';
    c.charset='utf-8';c.src='//rec.getsmartlook.com/recorder.js';h.appendChild(c);
    })(document);
    smartlook('init', '1d5b36d235efe9f2d85a45e8b2e4f788a57c3d9c');
</script>

<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-81808778-1', 'auto');
  ga('send', 'pageview');

</script>   

</head><!--/head-->

<body id="home" class="homepage">

<nav class="navbar navbar-default navigation">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="index.php"><img src="images/logo.png" alt="logo"></a>
    </div>
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav navbar-right">
        <li><a href="index.php">Accueil</a></li>
        <li><a href="pages/enerbioflex.php">Qui nous sommes</a></li>
        <li><a href="pages/espacepresse.php">Ils parlent de nous</a></li>
        <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Nos prestations <span class="caret"></span></a>
          <ul class="dropdown-menu">
                <li><a href="pages/acceptation.php">Acceptation sociale</a></li>
                <li><a href="pages/energieverte.php">Production d'énergie verte</a></li>
                <li><a href="pages/optimisation.php">Optimisation énergétique</a></li>
                <li><a href="pages/formation.php">Formations</a></li>
          </ul>
        </li>
        <li><a href="pages/references.php">Nos références</a></li>
        <li><a href="#get-in-touch">Contact</a></li>
      </ul>
    </div>
  </div>
</nav>

    <section id="main-slider">
        <div class="owl-carousel">
            <div class="item" style="background-image: url(images/slider/methanisation.jpg);">
                <div class="slider-inner">
                    <div class="container">
                        <div class="row">
                            <div class="col-sm-6">
                                <div class="carousel-content opaque">
                                    <h2 class="titre-opaque">Agriculteur, toujours avec vous</h2>
                                    <p>Nous vous accompagnons tout au long de votre projet de production d'énergie renouvelable</p>
                                    <a class="btn btn-primary btn-lg btn-slider" href="pages/energieverte.php">En savoir plus</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div><!--/.item-->
             <div class="item" style="background-image: url(images/slider/service.jpg);">
                <div class="slider-inner">
                    <div class="container">
                        <div class="row">
                            <div class="col-sm-6">
                                <div class="carousel-content opaque">
                                    <h2 class="titre-opaque">Du début à la fin</h2>
                                    <p>Un accompagnement tout au long de votre démarche d'économie d'énergie</p>
                                    <a class="btn btn-primary btn-lg btn-slider" href="optimisation.php">En savoir plus</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div><!--/.item-->
            <div class="item" style="background-image: url(images/slider/agricilture.jpg);">
                <div class="slider-inner">
                    <div class="container">
                        <div class="row">
                            <div class="col-sm-6">
                                <div class="carousel-content opaque">
                                    <h2 class="titre-opaque">Offre spéciale :</h2>
                                    <p>Bénéficiez d'un pré-diagnostic offert !</p>
                                    <a class="btn btn-primary btn-lg btn-slider" href="#get-in-touch">Contactez-nous</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div><!--/.item-->
        </div><!--/.owl-carousel-->
    </section><!--/#main-slider-->

    <section id="bloc-gris">
        <div class="container">
            <div class="row">
                <div class="col-sm-12 text-center">
                   <p class="impcon">EnerBioFlex, bureau d'études indépendant spécialisé en énergétique pour le monde agricole</p>
                </div>
            </div>
        </div>
    </section><!--/#cta-->

    <section id="point-un">
        <div class="hidden-xs hidden-sm hidden-md row">
            <div class="col-md-10 col-md-offset-1 col-lg-10 col-lg-offset-1">
                <div class="col-lg-1">
                    <img src="images/general/un.png" alt="point 1" >
                </div>
                <div class="col-lg-1 col-lg-offset-1 text-center">
                    <img src="images/general/thumb.png" class="illustration" style="padding-left: 20px;" alt="point 1">
                </div>
                <div class="col-lg-6 col-lg-offset-1 text-center">
                    <p class="point-p">
                        Nous sommes un bureau d'études indépendant, c'est pour cela que nous vous proposerons la solution qui vous conviendra le mieux
                    </p>
                </div>
            </div>
        </div>
        <div class="hidden-xs hidden-sm hidden-lg row">
            <div class="col-md-12">
                <div class="col-md-1">
                    <img src="images/general/un.png" >
                </div>
                <div class="col-md-9 col-md-offset-2 text-center">
                    <p>
                        Nous sommes un bureau d'études indépendant, c'est pour cela que nous vous proposerons la solution qui vous conviendra le mieux
                    </p>
                </div>
            </div>
        </div>
        <div class="hidden-xs hidden-md hidden-lg row">
            <div class="col-sm-12">
                <div class="col-sm-1">
                    <img src="images/general/un.png" >
                </div>
                <div class="col-sm-9 col-sm-offset-2 text-center">
                    <p>
                        Nous sommes un bureau d'études indépendant, c'est pour cela que nous vous proposerons la solution qui vous conviendra le mieux
                    </p>
                </div>
            </div>
        </div>
        <div class="hidden-sm hidden-md hidden-lg row">
            <div class="col-xs-10 col-xs-offset-1 text-center">
                <p>
                    Nous sommes un bureau d'études indépendant, c'est pour cela que nous vous proposerons la solution qui vous conviendra le mieux
                </p>
            </div>
        </div>
    </section>

    <section id="point-deux">
        <div class="hidden-xs hidden-sm hidden-md row">
            <div class="col-md-10 col-md-offset-1 col-lg-10 col-lg-offset-1">
                <div class="col-lg-1">
                    <img src="images/general/deux.png" >
                </div>
                <div class="col-lg-1 col-lg-offset-1 text-center">
                    <img src="images/general/earth.png" class="illustration" style="padding-left: 20px;" >
                </div>
                <div class="col-lg-6 col-lg-offset-1 text-center">
                    <p class="point-p">
                       Notre engagement, c'est de vous aider à réduire vos factures énergétiques à la ferme
                    </p>
                </div>
            </div>
        </div>
        <div class="hidden-xs hidden-sm hidden-lg row">
            <div class="col-md-12">
                <div class="col-md-1">
                    <img src="images/general/deux.png" >
                </div>
                <div class="col-md-9 col-md-offset-2 text-center">
                    <p>
                        Notre engagement, c'est de vous aider à réduire vos factures énergétiques à la ferme
                    </p>
                </div>
            </div>
        </div>
        <div class="hidden-xs hidden-md hidden-lg row">
            <div class="col-sm-12">
                <div class="col-sm-1">
                    <img src="images/general/deux.png" >
                </div>
                <div class="col-sm-9 col-sm-offset-2 text-center">
                    <p>
                        Notre engagement, c'est de vous aider à réduire vos factures énergétiques à la ferme
                    </p>
            </div>
        </div>
        </div>
        <div class="hidden-sm hidden-md hidden-lg row">
            <div class="col-xs-10 col-xs-offset-1 text-center">
                <p>
                    Notre engagement, c'est de vous aider à réduire vos factures énergétiques à la ferme
                </p>
            </div>
        </div>
    </section>

    <section id="point-trois">
        <div class="hidden-xs hidden-sm hidden-md row">
            <div class="col-md-10 col-md-offset-1 col-lg-10 col-lg-offset-1">
                <div class="col-lg-1">
                    <img src="images/general/trois.png" >
                </div>
                <div class="col-lg-1 col-lg-offset-1 text-center">
                    <img src="images/general/improvement.png" class="illustration" style="padding-left: 20px;" >
                </div>
                <div class="col-lg-6 col-lg-offset-1 text-center">
                    <p class="point-p">
                        Tous les jours, nous innovons afin de pouvoir vous proposer la meilleure solution
                    </p>
                </div>
            </div>
        </div>
        <div class="hidden-xs hidden-sm hidden-lg row">
            <div class="col-md-12">
                <div class="col-md-1">
                    <img src="images/general/trois.png" >
                </div>
                <div class="col-md-9 col-md-offset-2 text-center">
                    <p>
                        Tous les jours, nous innovons afin de pouvoir vous proposer la meilleure solution
                    </p>
                </div>
            </div>
        </div>
        <div class="hidden-xs hidden-md hidden-lg row">
            <div class="col-sm-12">
                <div class="col-sm-1">
                    <img src="images/general/trois.png" >
                </div>
                <div class="col-sm-9 col-sm-offset-2 text-center">
                    <p>
                        Tous les jours, nous innovons afin de pouvoir vous proposer la meilleure solution
                    </p>
                </div>
            </div>
        </div>
        <div class="hidden-sm hidden-md hidden-lg row">
            <div class="col-xs-10 col-xs-offset-1 text-center">
                <p>
                    Tous les jours, nous innovons afin de pouvoir vous proposer la meilleure solution
                </p>
            </div>
        </div>
    </section>


    <section id="bloc-gris">
        <div class="container">
                <div class="row">
                    <div class="col-xs-12 col-sm-6 col-md-3 col-lg-3">
                        <div class="row">
                            <div class="col-lg-12 text-center">
                                <img src="images/general/leaf.png" class="img-presta">
                            </div>
                            <div class="col-lg-12 text-center">
                                <hr class="presta-hr">
                                <h1 class="titre-presta">La méthanisation</h1>
                            </div>
                            <div class="col-lg-12 text-center">
                                 <a class="btn btn-primary btn-lg btn-slider" href="pages/energieverte/methanisation.php">En savoir plus</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-xs-12 col-sm-6 col-md-3 col-lg-3">
                        <div class="row">
                            <div class="col-lg-12 text-center">
                                <img src="images/general/sun.png" class="img-presta">
                            </div>
                            <div class="col-lg-12 text-center">
                                <hr class="presta-hr">
                                <h1 class="titre-presta">L'énergie solaire</h1>
                            </div>
                            <div class="col-lg-12 text-center">
                                 <a class="btn btn-primary btn-lg btn-slider" href="pages/energieverte/solaire.php">En savoir plus</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-xs-12 col-sm-6 col-md-3 col-lg-3">
                        <div class="row">
                            <div class="col-lg-12 text-center">
                                <img src="images/general/bio.png" class="img-presta">
                            </div>
                            <div class="col-lg-12 text-center">
                                <hr class="presta-hr">
                                <h1 class="titre-presta">La biomasse</h1>
                            </div>
                            <div class="col-lg-12 text-center">
                                 <a class="btn btn-primary btn-lg btn-slider" href="pages/energieverte/biomasse.php">En savoir plus</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-xs-12 col-sm-6 col-md-3 col-lg-3">
                        <div class="row">
                            <div class="col-lg-12 text-center">
                                <img src="images/general/flash.png" class="img-presta">
                            </div>
                            <div class="col-lg-12 text-center">
                                <hr class="presta-hr">
                                <h1 class="titre-presta">Optimisation d'énergie</h1>
                            </div>
                            <div class="col-lg-12 text-center">
                                <a class="btn btn-primary btn-lg btn-slider" href="pages/optimisation.php">En savoir plus</a>
                            </div>
                        </div>
                    </div>
                </div>
        </div>
    </section>

    <section id="bloc-blanc">
        <div class="container">
            <div class="row">
                <div class="col-sm-12 text-center">
                    <p class="titre-grey">Ils nous font déjà confiance</p>
                </div>
                    <div class="col-xs-12 col-sm-6 col-md-3 col-lg-3">
                        <div class="row">
                            <div class="col-lg-12 text-center">
                                <a href="https://www.isf-france.org/"><img src="images/partenaires/isf_ingenieurs_sans_frontieres.jpg" class="img-presta" alt="ingénieurs sans frontières logo" ></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-xs-12 col-sm-6 col-md-3 col-lg-3">
                        <div class="row">
                            <div class="col-lg-12 text-right">
                                <a href="http://www.institut-sainteloi-bapaume.fr/"><img src="images/partenaires/saint_eloi_bapaume.jpg" class="img-presta"></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-xs-12 col-sm-6 col-md-3 col-lg-3">
                        <div class="row">
                            <div class="col-lg-12 text-center">
                                <a href="https://www.facebook.com/Very.Important.Paysans/"><img src="images/partenaires/VIP_very_important_paysan.PNG" class="img-presta" alt="VIP logo"></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-xs-12 col-sm-6 col-md-3 col-lg-3">
                        <div class="row">
                            <div class="col-lg-6 text-center">
                                <a href="http://jeflabel.webflow.io/"><img src="images/partenaires/jef-label.png" class="img-presta" alt="agrophilia logo"></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-xs-12 col-sm-6 col-md-3 col-lg-3">
                        <div class="row">
                            <div class="col-lg-6 text-center">
                                <a href="http://www.nordappro.fr/"><img src="images/partenaires/nordappro.jpg" class="img-presta" alt="cooperative nord appro logo"></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-xs-12 col-sm-6 col-md-3 col-lg-3">
                        <div class="row">
                            <div class="col-lg-6 text-center">
                                <a href="http://agrophilia.fr/fr/accueil/"><img src="images/partenaires/agrophilia.png" class="img-presta" alt="agrophilia logo"></a>
                            </div>
                        </div>
                    </div>
                                       
                    
    </section><!--/#cta-->
    
    <section id="bloc-gris">
        <div class="container">
            <div class="row">
                <div class="col-sm-12 text-center">
                    <p class="titre-grey">Envie d'en savoir plus ?</p>
                </div>
                <div class="col-sm-4 text-right">
                  <img src="images/general/pres.png" width="60%" class="hidden-xs" alt="bloc blan">
                </div>
                <div class="col-lg-8 text-center">
                    <iframe src="https://prezi.com/embed/nais5pl492nr/?bgcolor=ffffff&amp;lock_to_path=0&amp;autoplay=0&amp;autohide_ctrls=0&amp;landing_data=bHVZZmNaNDBIWnNjdEVENDRhZDFNZGNIUE43MHdLNWpsdFJLb2ZHanI0a2R3VDRHZ1VmaVVGbTBJT2RIeTNRVkh3PT0&amp;landing_sign=UlK5CXYk8K0qUvaljNZrnGvmGGIdLNxVDVps3MgXhXk" allowfullscreen="" mozallowfullscreen="" webkitallowfullscreen="" id="iframe_container" frameborder="0" height="300" width="500"></iframe>
                </div>
            </div>
        </div>
    </section><!--/#cta-->
    
    <section id="get-in-touch">
        <div class="container">
            <div class="row">
                <div class="col-sm-12 text-center">
                    <p class="titre-grey">CONTACTEZ-NOUS</p>
                    <p class="impcon">Notre offre vous intéresse ou vous avez une question ? N'hésitez pas à nous contacter, nous vous répondrons dans les plus brefs délais.</p>
                </div>

                <div class="col-sm-6 col-lg-offset-1">
                    <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d41526.32004127519!2d1.9910770815429701!3d49.42034581424032!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47e7037895c05729%3A0x80710e420faa164e!2sEnerBioFlex!5e0!3m2!1sfr!2sfr!4v1460963959373" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
                </div>

                <div class="col-sm-4 col-sm-offset-1">
                    <form action="pages/mail.php" method="post">
                        <div class="form-group">
                            <input type="text" name="name" id="name" class="form-control" placeholder="Nom" required>
                        </div>
                        <div class="form-group">
                            <input type="email" name="email" id="email" class="form-control" placeholder="Email" required>
                        </div>
			<div class="form-group">
                            <input type="tel" name="tel" id="tel" class="form-control" placeholder="Téléphone" required>
                        </div>
                        <div class="form-group">
                            <input type="text" name="subject" id="subject" class="form-control" placeholder="Sujet" required>
                        </div>
                        <div class="form-group">
                            <textarea placeholder="Votre message" id="message" name="message" class="form-control" required></textarea>
                        </div>
                        <button type="submit" class="btn btn-primary">Envoyer</button>
                    </form>
                </div>

                <!--
                <div class="col-sm-4 col-sm-offset-1">
                    <div class="contact-form">
                        <form id="main-contact-form" name="contact-form" method="post" action="mail.php" target="post-contact-form">
                            <div class="form-group">
                                <input type="text" name="name" class="form-control" placeholder="Nom" required>
                            </div>
                            <div class="form-group">
                                <input type="email" name="email" class="form-control" placeholder="Email" required>
                            </div>
                            <div class="form-group">
                                <input type="text" name="subject" class="form-control" placeholder="Sujet" required>
                            </div>
                            <div class="form-group">
                                <textarea name="message" class="form-control" rows="8" placeholder="Message" required></textarea>
                            </div>
                            <button type="submit" class="btn btn-primary">Envoyer</button>
                        </form>
                    </div>
                </div>
                -->

            </div>
        </div>
    </section><!--/#get-in-touch-->

    <footer id="footer">
        <div class="container">
            <div class="row">
                <div class="col-sm-6">
                    &copy; 2016 Enerbioflex
                </div>
                <div class="col-sm-6">
                    <ul class="social-icons">
			<li>Suivez nous sur les réseaux sociaux <li>
                        <li><a href="http://www.facebook.com/enerbioflex/info/?tab=page_info"><i class="fa fa-facebook"></i></a></li>
                        <li><a href="https://twitter.com/enerbioflex"><i class="fa fa-twitter"></i></a></li>
                        <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                        <li><a href="#"><i class="fa fa-youtube"></i></a></li>
                        <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                    </ul>
                </div>
                <div class="col-sm-6">
                    Contactez nous par télphone : 06 87 38 54 53 / 06 80 45 39 59
                </div>
            </div>
        </div>
    </footer><!--/#footer-->

    <div class="modal fade" id="no_confirmation">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <h4 class="text-center">Votre message n'a pas pu être envoyé</h4>
                    <p class="text-center">Veuillez recommencer ultérieurement.<br>Si le problème persiste, contactez-nous à l'adresse suivante : contact@enerbioflex.fr</p>
                </div>
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->

    <script src="js/jquery.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="http://maps.google.com/maps/api/js?sensor=true"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/mousescroll.js"></script>
    <script src="js/smoothscroll.js"></script>
    <script src="js/jquery.prettyPhoto.js"></script>
    <script src="js/jquery.isotope.min.js"></script>
    <script src="js/jquery.inview.min.js"></script>
    <script src="js/wow.min.js"></script>
    <script src="js/main.js"></script>
</body>
</html>